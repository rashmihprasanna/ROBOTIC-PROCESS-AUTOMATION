﻿namespace SampleActivities.Basic.DataExtraction
{
    /// <summary>
    /// Interaction logic for SimpleExtractorDesigner.xaml
    /// </summary>
    public partial class SimpleExtractorDesigner
    {
        public SimpleExtractorDesigner()
        {
            InitializeComponent();
        }
    }
}
