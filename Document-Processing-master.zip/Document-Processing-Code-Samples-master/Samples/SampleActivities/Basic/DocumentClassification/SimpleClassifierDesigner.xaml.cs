﻿namespace SampleActivities.Basic.DocumentClassification
{
    /// <summary>
    /// Interaction logic for SimpleClassifierDesigner.xaml
    /// </summary>
    public partial class SimpleClassifierDesigner
    {
        public SimpleClassifierDesigner()
        {
            InitializeComponent();
        }
    }
}
