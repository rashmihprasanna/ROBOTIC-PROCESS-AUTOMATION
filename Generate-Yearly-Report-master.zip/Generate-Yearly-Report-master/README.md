# Generate-Yearly-Report
 UiPath Level 3 - Advanced Training, Exercise 3
